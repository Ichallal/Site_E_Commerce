const cartItemsContainer = document.getElementById("cart-items");
const totalAmountCell = document.getElementById("total-amount-cell");
const storedCart = localStorage.getItem("cart");
const cart = storedCart ? JSON.parse(storedCart) : [];

// Assurez-vous que la quantité de chaque produit est 1
cart.forEach(item => {
    item.quantity = 1;
});

function displayCartItems() {
    cartItemsContainer.innerHTML = "";
    let totalAmount = 0;

    cart.forEach((item, index) => {
        const cartItemRow = document.createElement("tr");

        const removeButtonCell = document.createElement("td");
        const removeButtonElement = document.createElement("button");
        removeButtonElement.textContent = "Remove";
        removeButtonElement.addEventListener("click", () => removeCartItem(index));
        removeButtonCell.appendChild(removeButtonElement);
        cartItemRow.appendChild(removeButtonCell);

        const itemDetails = ["name", "price", "quantity"];
        itemDetails.forEach(detail => {
            const itemDetailCell = document.createElement("td");
            itemDetailCell.textContent = item[detail];
            cartItemRow.appendChild(itemDetailCell);
        });

        const itemSubtotalData = document.createElement("td");
        const itemSubtotal = item.price * item.quantity;
        itemSubtotalData.textContent = `$${itemSubtotal.toFixed(2)}`;
        cartItemRow.appendChild(itemSubtotalData);

        cartItemsContainer.appendChild(cartItemRow);
        totalAmount += itemSubtotal;
    });

    totalAmountCell.textContent = `$${totalAmount.toFixed(2)}`;

    const totalRow = document.createElement("tr");
    const totalLabelCell = document.createElement("td");
    totalLabelCell.textContent = "Total";
    totalLabelCell.setAttribute("colspan", "4");
    totalRow.appendChild(totalLabelCell);

    const totalAmountData = document.createElement("td");
    totalAmountData.textContent = `$${totalAmount.toFixed(2)}`;
    totalRow.appendChild(totalAmountData);

    cartItemsContainer.appendChild(totalRow);
}

function removeCartItem(index) {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    displayCartItems();
}

displayCartItems();
const paymentButton = document.getElementById("payment-button");
const paymentModal = document.getElementById("payment-modal");
const confirmPaymentButton = document.getElementById("confirm-payment");
const paymentMethodSelect = document.getElementById("payment-method");

// Gérer le clic sur le bouton de paiement
paymentButton.addEventListener("click", () => {
    paymentModal.style.display = "block";
});

// Gérer le clic sur le bouton de confirmation de paiement
confirmPaymentButton.addEventListener("click", () => {
    const selectedPaymentMethod = paymentMethodSelect.value;
    
    // Effectuer des actions en fonction de la méthode de paiement choisie
    if (selectedPaymentMethod === "credit-card") {
        // Logique pour le paiement par carte de crédit
        alert("Paiement par carte de crédit effectué !");
    } else if (selectedPaymentMethod === "paypal") {
        // Logique pour le paiement via PayPal
        alert("Paiement via PayPal effectué !");
    }
    
    // Fermer la fenêtre modale après le paiement
    paymentModal.style.display = "none";
});
