
        const cartItemsContainer = document.getElementById("cart-items");
        const addToCartButtons = document.querySelectorAll(".add-to-cart");
        const cart = [];

        addToCartButtons.forEach(button => {
            button.addEventListener("click", function(event) {
                const product = event.currentTarget.closest(".pro");
                const productName = product.querySelector("h5").textContent;
                const productPrice = parseFloat(product.querySelector("h4").textContent.slice(1));

                const item = {
                    name: productName,
                    price: productPrice
                };
                
                addToCart(item);
                updateCartDisplay();
            });
        });

        function addToCart(item) {
            cart.push(item);
        }

        function updateCartDisplay() {
            cartItemsContainer.innerHTML = ""; // Clear previous cart items
            
            cart.forEach(item => {
                const cartItemRow = document.createElement("tr");

                const itemNameData = document.createElement("td");
                itemNameData.textContent = item.name;
                cartItemRow.appendChild(itemNameData);

                const itemPriceData = document.createElement("td");
                itemPriceData.textContent = `$${item.price.toFixed(2)}`;
                cartItemRow.appendChild(itemPriceData);

                cartItemsContainer.appendChild(cartItemRow);
            });
        }
