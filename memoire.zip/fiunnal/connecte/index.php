<?php 
session_start();

	include("connection.php");
    include("functions.php");
	$user_data = check_login($con);
	
    
?>

<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> Mia Mimoucha </title>
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<link rel="stylesheet" href="style/style.css">
</head>

<body>
	<section id="header">
		<a href="#"><img width="50px" src="img/log-mia.png" class="logo" alt=""></a>
		<div>
			<ul id="navbar">
				<li><a class="active" href="index.html">Accueil</a></li>
				<li><a href="shop.html">Boutique</a></li>
				<li><a href="blog.html">Blog</a></li>
				<li><a href="about.html">À Propos</a></li>
				<li><a href="contact.html">Contact</a></li>
				<li id="lg-bag"><a href="cart.html"><i class="far fa-shopping-bag"></i></a></li>
				<a href="#" id="close"><i class="far fa-times"></i></a>
				<?php if ($user_data) { ?>
				<li><a href="logout.php">Déconnexion</a></li>
				<?php } ?>
				<a href="#" id="close"><i class="far fa-times"></i></a>

			</ul>
			<div id="mobile">
				<a href="cart.html"><i class="far fa-shopping-bag"></i></a>
				<i id="bar" class="fas fa-outdent"></i>
			</div>
	</section>

	<section id="hero">
		<div id="hero-content">
			<h4>Découvrez nos offres spéciales</h4>
			<h2>Économies exceptionnelles</h2>
			<h1>Sur tous vos achats</h1>
			<button><a href="shop.html">Explorer Maintenant</a></button>
		</div>
		<img src="img/i44.png" alt="">
	</section>



	<section id="feature" class="section-p1">
		<div class="fe-box">
			<img src="img/features/f1.png" alt="">
			<h6>Livraison Gratuite</h6>
		</div>
		<div class="fe-box">
			<img src="img/features/f2.png" alt="">
			<h6>Commande en Ligne</h6>
		</div>
		<div class="fe-box">
			<img src="img/features/f3.png" alt="">
			<h6>Économisez de l'Argent</h6>
		</div>
		<div class="fe-box">
			<img src="img/features/f4.png" alt="">
			<h6>Promotions</h6>
		</div>
		<div class="fe-box">
			<img src="img/features/f5.png" alt="">
			<h6>Vente Heureuse</h6>
		</div>
		<div class="fe-box">
			<img src="img/features/f6.png" alt="">
			<h6>Support 24/7</h6>
		</div>
	</section>


	<section id="product1" class="section-p1">
		<h2>Featured Products</h2>
		<p>Summer Collection New Morden Design</p>
		<div class="pro-container">
			<div class="pro">
				<img src="img/products/n1.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n2.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n3.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n3.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n2.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n1.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n3.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n1.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
		</div>
	</section>

	<section id="banner" class="section-m1">

	</section>

	<section id="product1" class="section-p1">
		<h2>New Arrivals</h2>
		<p>Summer Collection New Morden Design</p>
		<div class="pro-container">
			<div class="pro">
				<img src="img/products/n1.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<button class="add-to-cart" data-product-id="product1">
					<i class="fal fa-shopping-cart cart"></i></a></button>
			</div>
			<div class="pro">
				<img src="img/products/n2.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n3.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n1.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n2.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n3.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n1.jpg" alt="">
				<div class="des">
					<span>adidas</span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
			<div class="pro">
				<img src="img/products/n3.jpg" alt="">
				<div class="des">
					<span>Chaussure rouge </span>
					<h5>Cartoon Astronaut T-Shirts</h5>
					<div class="star">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</div>
					<h4>$78</h4>
				</div>
				<a href="#"><i class="fal fa-shopping-cart cart"></i></a>
			</div>
		</div>
	</section>

	<section id="sm-banner" class="section-p1">
		<div class="banner-box">
			<h4>crazy deals</h4>
			<h2>buy 1 get 1 free</h2>
			<span>The best classic dress is on sale at cara</span>
			<button class="white"> <a href="pages/super_deal.html">Learn More</a></button>
		</div>
		<div class="banner-box banner-box2">
			<h4>spring/summer</h4>
			<h2>upcomming season</h2>
			<span>The best classic dress is on sale at cara</span>
			<button class="white">Collection</button>
		</div>
	</section>

	<section id="banner3">
		<div class="banner-box">
			<h2>SEASONAL SALE</h2>
			<h3>Winter Collection -50% OFF</h3>
		</div>
		<div class="banner-box banner-box2">
			<h2>NEW FOOTWEAR COLLECTION </h2>
			<h3>Spring / Summer 2022</h3>
		</div>
		<div class="banner-box banner-box3">
			<h2>T-SHIRTS</h2>
			<h3>New Trendy Prints</h3>
		</div>
	</section>
	<section id="newsletter" class="section-p1 section-m1">
		<div class="newstext">
			<h4>Sign Up For Newsletters</h4>
			<p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
		</div>
		<div class="form">
			<form action="process_registration.php" method="post">
				<input type="email" name="email" placeholder="Your email address" required>
				<button type="submit" class="normal">Sign Up</button>
			</form>
		</div>
	</section>

	<footer class="section-p1">
		<div class="col">
			<!--   <img class="logo" width="100px" src="img/log-mia.png" alt="">-->
			<h4>Contact</h4>
			<p><strong>Address: </strong> Igran Harath Sidi Ayad Sidi Aich Bejaia Algerie</p>
			<p><strong>Phone:</strong> +33 753 863 200</p>
			<p><strong>Hours:</strong> 24/7</p>
			<div class="follow">
				<h4>Follow Us</h4>
				<div class="icon">
					<i class="fab fa-facebook-f"></i>
					<i class="fab fa-twitter"></i>
					<i class="fab fa-instagram"></i>
					<i class="fab fa-pinterest-p"></i>
					<i class="fab fa-youtube"></i>
				</div>
			</div>
		</div>

		<div class="col">
			<h4>À Propos</h4>
			<a href="#">À Propos de Nous</a>
			<a href="#">Informations de Livraison</a>
			<a href="#">Politique de Confidentialité</a>
			<a href="#">Termes et Conditions</a>
			<a href="contact.html">Nous Contacter</a>
		</div>

		<div class="col">
			<h4>Mon Compte</h4>
			<a href="connecte/index.php">Se Connecter</a>
			<a href="cart.html">Voir le Panier</a>
			<a href="#">Suivre Ma Commande</a>
			<a href="#">Aide</a>
		</div>

		<div class="col install">
			<h4>Installer l'Application</h4>
			<p>Depuis l'App Store ou Google Play</p>
			<div class="row">
				<img src="img/pay/app.jpg" alt="">
				<img src="img/pay/play.jpg" alt="">
			</div>
			<p>Passerelles de Paiement Sécurisées</p>
			<img src="img/pay/pay.png" alt="">
		</div>

		<div class="copyright">
			<p style="font-weight: bold; font-style: italic;">© 2023, Ichallal Lamia & co</p>
		</div>
	</footer>
	<script src="script/js.js"></script>
	<script src="script/script.js"></script>
</body>

</html>