<?php
// Je commence une session pour gérer les sessions utilisateur
session_start();

// J'inclus la connexion à la base de données et les fonctions
include("connection.php");
include("functions.php");

// Je vérifie si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Je récupère le nom d'utilisateur et le mot de passe saisis
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    // Je vérifie si le nom d'utilisateur n'est pas vide et est une adresse e-mail valide
    if (!empty($user_name) && filter_var($user_name, FILTER_VALIDATE_EMAIL)) {

        // Je fais une requête à la base de données pour récupérer les données de l'utilisateur
        $query = "SELECT * FROM users WHERE user_name = '$user_name' LIMIT 1";
        $result = mysqli_query($con, $query);

        // Je vérifie si la requête a réussi
        if ($result) {
            // Je vérifie si les données de l'utilisateur existent et si le nombre de lignes retournées est supérieur à 0
            if ($result && mysqli_num_rows($result) > 0) {

                // Je récupère les données de l'utilisateur à partir du résultat de la requête
                $user_data = mysqli_fetch_assoc($result);

                // Je vérifie si le mot de passe saisi correspond au mot de passe enregistré
                if ($user_data['password'] === $password) {

                    // J'attribue une variable de session pour stocker l'ID de l'utilisateur
                    $_SESSION['user_id'] = $user_data['user_id'];

                    // Je redirige l'utilisateur vers la page d'index
                    header("Location: index.php");
                    // J'arrête l'exécution ultérieure
                    die;
                }
            }
        }
        // J'affiche un message d'erreur pour un mauvais e-mail ou mot de passe
        echo "Mauvaise adresse e-mail ou mot de passe !";
    } else {
        // J'affiche un message d'erreur pour un e-mail ou mot de passe non valide
        echo "Veuillez entrer une adresse e-mail et un mot de passe valides !";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="style/style_login.css">

</head>

<body>
	<div id="box">
		<!-- Formulaire pour recueillir les entrées de l'utilisateur -->
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: white;">Connexion</div>

			<!-- Champs d'entrée pour le nom d'utilisateur et le mot de passe -->
			<input id="text" type="text" name="user_name"><br><br>
			<input id="text" type="password" name="password"><br><br>

			<!-- Bouton de connexion -->
			<input id="button" type="submit" value="Connexion"><br><br>

			<!-- Lien vers la page d'inscription -->
			<a href="signup.php">Cliquez pour vous inscrire</a><br><br>
		</form>
	</div>
</body>

</html>