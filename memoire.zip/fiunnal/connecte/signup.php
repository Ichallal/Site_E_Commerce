<?php
include("connection.php");
include("functions.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if (!empty($user_name) && filter_var($user_name, FILTER_VALIDATE_EMAIL)) {

        $check_query = "SELECT * FROM users WHERE user_name = '$user_name' LIMIT 1";
        $check_result = mysqli_query($con, $check_query);

        if ($check_result && mysqli_num_rows($check_result) > 0) {
            echo "An account with this email already exists.";
            die;
        }

        // Insert new user data into the database
        $insert_query = "INSERT INTO users (user_name, password) VALUES ('$user_name', '$password')";
        $insert_result = mysqli_query($con, $insert_query);

        if ($insert_result) {
            echo "Registration successful. You can now log in.";
        } else {
            echo "Registration failed. Please try again later.";
        }
    } else {
        echo "Please enter a valid email and password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Signup</title>
	<link rel="stylesheet" type="text/css" href="style/style_sign.css">

</head>
<body>
		<div id="box">
		
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: white;">Signup</div>

			<input id="text" type="text" name="user_name"><br><br>
			<input id="text" type="password" name="password"><br><br>

			<input id="button" type="submit" value="Signup"><br><br>

			<a href="login.php">Click to Login</a><br><br>
		</form>
	</div>
</body>
</html>