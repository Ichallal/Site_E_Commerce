<?php
// Placez ce code au début de votre page pour démarrer la session et inclure les fichiers nécessaires
session_start();
include("connection.php");
include("functions.php");
// Vérification de la connexion utilisateur
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header("Location: login2.php"); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
}


// Vérification de la connexion utilisateur
if (!isLoggedIn()) {
    header("Location: login2.php"); // Redirigez vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
}

// Traitement du formulaire de mise à jour
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user_id = $_SESSION['user_id'];
    $full_name = $_POST['full_name'];
    $address = $_POST['address'];
    $preferences = $_POST['preferences'];

    // Enregistrez les informations dans la base de données (notez que ceci est simplifié et ne traite pas les erreurs)
    $updateQuery = "UPDATE users SET full_name = '$full_name', address = '$address', preferences = '$preferences' WHERE user_id = $user_id";
    mysqli_query($con, $updateQuery);

    echo "Informations mises à jour avec succès!";
}

// Obtenez les informations actuelles de l'utilisateur
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($con, $query);
$user_data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mon Profil</title>
</head>
<body>
    <h1>Mon Profil</h1>
    <form method="post">
        <label>Nom complet:</label>
        <input type="text" name="full_name" value="<?php echo $user_data['full_name']; ?>"><br><br>

        <label>Adresse:</label>
        <input type="text" name="address" value="<?php echo $user_data['address']; ?>"><br><br>

        <label>Préférences:</label>
        <textarea name="preferences"><?php echo $user_data['preferences']; ?></textarea><br><br>

        <input type="submit" value="Mettre à jour">
    </form>
    <br>
    <a href="logout.php">Déconnexion</a>
</body>
</html>
