<?php
// Connexion à la base de données MySQL
$host = "localhost";
$user = "root";
$password = "";
$dbname = "mysql";
$table = "enregistration_site";

$conn = new mysqli($host, $user, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupérer l'adresse e-mail depuis le formulaire
if (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Utilisation d'une requête préparée pour l'insertion
    $stmt = $conn->prepare("INSERT INTO $table (email) VALUES (?)");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        echo "You have successfully subscribed to the newsletter.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Fermer la connexion à la base de données
    $stmt->close();
}

$conn->close();
?>
