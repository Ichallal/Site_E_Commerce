<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

function envoie_mail($from_name, $from_email, $subject, $message) {
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->SMTPDebug = 0;
    $mail->SMTPSecure = 'ssl';
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'lamiaro301@gmail.com';
    $mail->Password = 'zhglhi1995';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;
    $mail->setFrom($from_email, $from_name);
    $mail->addAddress('lamiaro301@gmail.com', 'miamia');
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->setLanguage('fr', '/optional/path/to/language/directory/');

    if (!$mail->Send()) {
        return false;
    } else {
        return true;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (envoie_mail($_POST['name'], $_POST['email'], $_POST['subject'], $_POST['message'])) {
        echo 'OK';
    } else {
        echo "Une erreur s'est produite";
    }
} else {
    echo "Form submission method is not valid.";
}
?>
